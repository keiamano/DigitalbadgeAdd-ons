<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/
require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot.'/report/outline/locallib.php');
require_once($CFG->dirroot.'/report/outline/lib.php');
require_once($CFG->dirroot.'/course/lib.php');
require_once($CFG->libdir .'/badgeslib.php');
require_once($CFG->libdir .'/filelib.php');
require_once(__DIR__ .'/../../badges/renderer.php');
require_once(__DIR__ . '/classes/comment_form.php');
require_once(__DIR__ . '/classes/detail_form.php');
require_once(__DIR__ . '/classes/access_ctl_form.php');
require_once(__DIR__ . '/classes/browse_history_form.php');

defined('MOODLE_INTERNAL') || die();

function local_ku_badge_plugins_extend_settings_navigation () {
    global $SCRIPT;
    
    if (strpos($SCRIPT, '/badges/badge.php') !== false) {
        badge_comment_display();
    }    
    else if (strpos($SCRIPT, '/badges/overview.php'  ) !== false ||
             strpos($SCRIPT, '/badges/edit.php'      ) !== false ||
             strpos($SCRIPT, '/badges/criteria.php'  ) !== false ||
             strpos($SCRIPT, '/badges/recipients.php') !== false ||
             strpos($SCRIPT, '/local/ku_badge_plugins/detail.php') !== false ){
        badge_comment_tab_add(0);
    }
    
    if (strpos($SCRIPT, '/badges/badge.php') !== false) {
        badge_detail_display();
    }
    else if (strpos($SCRIPT, '/badges/overview.php'  ) !== false ||
             strpos($SCRIPT, '/badges/edit.php'      ) !== false ||
             strpos($SCRIPT, '/badges/criteria.php'  ) !== false ||
             strpos($SCRIPT, '/badges/recipients.php') !== false ||
             strpos($SCRIPT, '/local/ku_badge_plugins/comment.php') !== false ){
        badge_detail_tab_add(0);
    }
    
    if (strpos($SCRIPT, '/badges/badge.php') !== false) {
        $id    = required_param('hash', PARAM_ALPHANUM);
        $issued_badge = new issued_badge($id);
        $badgeid  = $issued_badge->badgeid;
        $badge = new badge($badgeid);
        if( $badge->type == BADGE_TYPE_COURSE ){
            echo '
            <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/external/jquery/jquery.js').'"></script>
            <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.js').'"></script>
            <link type="text/css" rel="stylesheet" href="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.css').'" />
            <script type="text/javascript">
                function addOnload(func) {
                    try {
                        window.addEventListener("load", func, false);
                    } catch(e) {
                        window.attachEvent("onload", func);
                    }
                }
            </script>
            ';
            badge_access_display();
            badge_access_ctl_btn_add();
            check_badge_access_ctl();
            
            get_badge_browse_history();
        }
    }
    
}


/* --------------------
ku_badge_add_comment
--------------------- */
function badge_comment_display() {
    $id = required_param('hash', PARAM_ALPHANUM);
    $issued_badge = new issued_badge($id);
    $userid  = $issued_badge->recipient->id;
    $badgeid = $issued_badge->badgeid;
    $badge = new badge($badgeid);
    if( $badge->type != BADGE_TYPE_COURSE ){ return;}
    $accessmode = "0";
    
    global $DB,$USER;
    $dbman = $DB->get_manager();
    $accessctrl=$dbman->table_exists('badge_access_ctl');
    if( $userid == $USER->id ){ $accessmode = "1";}
    else if($accessctrl){
        // DB読込
        $accessdata = $DB->get_record_sql("SELECT ac.id, ac.badgeid, ac.userid, ac.accessmode, ac.accesspass
                                FROM {badge_access_ctl} ac WHERE ac.badgeid=$badgeid and ac.userid=$userid");
        if(!empty($accessdata)) {
            $accessmode = $accessdata->accessmode;
            if( $accessmode=="0" ) {
                if(is_comment_in_course($badgeid)) { $accessmode = "1";}
            }
        }
    }
    if( $accessmode == "0" ){ return;}

    echo '
    <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/external/jquery/jquery.js').'"></script>
    <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.js').'"></script>
    <link type="text/css" rel="stylesheet" href="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.css').'" />
    <script type="text/javascript">
        function addOnload(func) {
            try {
                window.addEventListener("load", func, false);
            } catch(e) {
                window.attachEvent("onload", func);
            }
        }
    </script>
    ';
    echo '
    <script type="text/javascript">
        function add_comment_div() {
            var dispOn = '.($accessmode=="1" ? "true" : "false").';
            var divTagComment = document.createElement("div");
            divTagComment.id  = "badge_add_comment_display";
            divTagComment.name= "badge_add_comment_display";
            divTagComment.style.display = dispOn===false ? "none" : "block";
            var divDetails = document.getElementById("badge-details");
            divDetails.appendChild(divTagComment);
        }
        addOnload( add_comment_div );
    </script>
    ';       
    add_comment( $badgeid, $userid );
}

function add_comment( $badgeid, $userid )
{
    global $DB;
    
    $sql  = "";
    $sql .= " SELECT";
    $sql .= "   u.*, b.userid, c.userid, c.badge_comment";
    $sql .= " FROM {user} u";
    $sql .= "   INNER JOIN {badge_issued} b ON b.badgeid = $badgeid AND b.userid = u.id";
    $sql .= "   LEFT JOIN {badge_comment} c ON c.badgeid = $badgeid AND c.userid = u.id";
    $sql .= " WHERE c.badgeid = $badgeid  AND c.userid = $userid AND u.deleted = 0" ;
    $rs = $DB->get_recordset_sql($sql);
    if(!$rs){ return false;}

    $badge_comment = "";
    $totalcount = $DB->count_records('badge_comment', array('badgeid' => $badgeid, 'userid' => $userid));
    if($totalcount>0){
        $badge_comment .= html_writer::start_tag('dl');
        foreach ($rs as $comment) {
            $arraycom = explode("\n", $comment->badge_comment);
            $arraycom = array_map('trim', $arraycom);
            $arraycom = array_filter($arraycom, 'strlen');
            $arraycom = array_values($arraycom);
            if( count($arraycom) ) {
                foreach($arraycom as $com){
                    $badge_comment .= html_writer::tag('dd', $com);
                }
            }
            else {
                $badge_comment .= html_writer::tag('dd',str_replace(array("\r\n", "\r", "\n"), '',$comment->badge_comment));
            }
        }
        $badge_comment .= html_writer::end_tag('dl');
    }
    $rs->close();

    if($badge_comment==""){ return false;}

    $comment_title = get_string( 'comment_title', 'local_ku_badge_plugins' );
    
    echo '
    <script type="text/javascript">
        function add_comment() {
            var comment_title = "'.$comment_title.'";
            var comment_text  = "'.$badge_comment.'";
            var h3Tag1 = document.createElement("h3");
            h3Tag1.innerHTML = comment_title;

            var divTag1 = document.createElement("div");
            divTag1.id = "badge_add_div_comment";
            divTag1.style = "margin: 20px;";
            divTag1.innerHTML = comment_text;

            var divAddDisplay = document.getElementById("badge_add_comment_display");
            divAddDisplay.appendChild(h3Tag1);
            divAddDisplay.appendChild(divTag1);
        }
        addOnload( add_comment );
    </script>
    ';

    return true;
}

function is_comment_in_course($badgeid) {
    global $CFG, $DB, $USER;
   
    if (empty($CFG->profileroles)) {
        return false;
    }

    $userid = $USER->id;
    $badgedat = $DB->get_record('badge', array('id'=>$badgeid), '*', MUST_EXIST);
    $courseid = $badgedat->courseid;

    if ($courseid == SITEID) {
        $context = context_system::instance();
    } else {
        $context = context_course::instance($courseid);
    }

    list($rallowed, $params) = $DB->get_in_or_equal(explode(',', $CFG->profileroles), SQL_PARAMS_NAMED, 'a');
    list($contextlist, $cparams) = $DB->get_in_or_equal($context->get_parent_context_ids(true), SQL_PARAMS_NAMED, 'p');
    $params = array_merge($params, $cparams);

    if ($coursecontext = $context->get_course_context(false)) {
        $params['coursecontext'] = $coursecontext->id;
    } else {
        $params['coursecontext'] = 0;
    }

    $sql = "SELECT DISTINCT r.id, r.name, r.shortname, r.sortorder, rn.name AS coursealias
              FROM {role_assignments} ra, {role} r
         LEFT JOIN {role_names} rn ON (rn.contextid = :coursecontext AND rn.roleid = r.id)
             WHERE r.id = ra.roleid
                   AND ra.contextid $contextlist
                   AND r.id $rallowed
                   AND ra.userid = :userid
          ORDER BY r.sortorder ASC";
    $params['userid'] = $userid;

    $rolenames = [];

    if ($roles = $DB->get_records_sql($sql, $params)) {
        $rolenames = role_fix_names($roles, $context, ROLENAME_ALIAS, true);   // Substitute aliases
        foreach ($rolenames as $roleid => $rolename) {
            //    echo "rolename=[".$roleid.": ".$rolename."]";
            if( $roleid==1 || $roleid==2 || $roleid==3 ) {
                return true;
            }
        }
    }
    return false;
}


/* --------------------
ku_badge_add_detail
--------------------- */
function badge_detail_display(){
    $id       = required_param('hash', PARAM_ALPHANUM);
    $issued_badge = new issued_badge($id);
    $userid   = $issued_badge->recipient->id;
    $badgeid  = $issued_badge->badgeid;
    $badge = new badge($badgeid);
    if( $badge->type != BADGE_TYPE_COURSE ){ return;}
     $accessmode = "0";
    
    global $DB, $USER;
    $dbman = $DB->get_manager();
    $accessctrl=$dbman->table_exists('badge_access_ctl');
    if( $userid == $USER->id ){ $accessmode = "1";}
    else if($accessctrl){
        // DB�ɹ�
        $accessdata = $DB->get_record_sql("SELECT ac.id, ac.badgeid, ac.userid, ac.accessmode, ac.accesspass
                                FROM {badge_access_ctl} ac WHERE ac.badgeid=$badgeid and ac.userid=$userid");
        if( !empty($accessdata)) {
            $accessmode = $accessdata->accessmode;
            if( $accessmode=="0" ) {
                if(is_detail_in_course($badgeid)) { $accessmode = "1";}
            }
        }
    }
    if( $accessmode == "0" ){ return;}

    echo '
    <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/external/jquery/jquery.js').'"></script>
    <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.js').'"></script>
    <link type="text/css" rel="stylesheet" href="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.css').'" />
    <script type="text/javascript">
        function addOnload(func) {
            try {
                window.addEventListener("load", func, false);
            } catch(e) {
                window.attachEvent("onload", func);
            }
        }
    </script>
    ';
    echo '
    <script type="text/javascript">
        function add_comment_div() {
            var dispOn = '.($accessmode=="1" ? "true" : "false").';
            var divTagComment = document.createElement("div");
            divTagComment.id  = "badge_add_detail_display";
            divTagComment.name= "badge_add_detail_display";
            divTagComment.style.display = dispOn===false ? "none" : "block";
            var divDetails = document.getElementById("badge-details");
            divDetails.appendChild(divTagComment);
        }
        addOnload( add_comment_div );
    </script>
    ';       

    add_detail( $badgeid, $userid );
}

function add_detail( $badgeid, $userid ){
    global $DB, $PAGE, $CFG, $OUTPUT, $USER;
    $id = required_param('hash', PARAM_ALPHANUM);
    $viewDatas=[];
    $mode = 'complete';
    $coursecount = $DB->count_records('course') - 1;
    if(!$coursecount){ return false;}

    $user = $DB->get_record('user', array('id'=>$userid, 'deleted'=>0), '*', MUST_EXIST);
    $personalcontext = context_user::instance($user->id);
    $viewDatas[] = $OUTPUT->context_header(
        array(
        'heading'     => fullname($user),
        'user'        => $user,
        'usercontext' => $personalcontext
    ), 2);
    $badge = $DB->get_record('badge', array('id'=>$badgeid), '*', MUST_EXIST);
    $courseid = $badge->courseid;
    if($courseid<=0)return false;
    
    $course = $DB->get_record('course', array('id'=>$courseid), '*', MUST_EXIST);
    $coursecontext = context_course::instance($course->id);
    if ($USER->id != $user->id
            and has_capability('moodle/user:viewuseractivitiesreport', $personalcontext)
            and !is_enrolled($coursecontext, $USER) 
            and is_enrolled($coursecontext, $user)) {
        return false;
    }
    if (!report_outline_can_access_user_report($user, $course, true)) {
// 2017.12.19 S.Miyamoto DEL START >> �������������
//        require_capability('report/outline:view', $coursecontext);
// 2017.12.19 S.Miyamoto DEL END   <<
    }

    $PAGE->navigation->extend_for_user($user);
    $PAGE->navigation->set_userid_for_parent_checks($user->id); // see MDL-25805 for reasons and for full commit reference for reversal when fixed.
    // Create the appropriate breadcrumb.
    $navigationnode = array(
            'url' => new moodle_url('/badges/badge.php', array('hash' => $id))
        );
    if ($mode === 'complete') { $navigationnode['name'] = get_string('completereport');}
    else                      { $navigationnode['name'] = get_string('outlinereport' );}
    this_add_report_nodes( $user->id, $navigationnode );

    // Trigger a report viewed event.
    $event = \report_outline\event\report_viewed::create(
                array('context' => context_course::instance($course->id),
                'relateduserid' => $userid, 'other' => array('mode' => $mode)));
    $event->trigger();

    $viewDatas[].="<h2>$course->fullname</h2>";

    $modinfo = course_modinfo::instance($course, $user->id);
    $sections = $modinfo->get_section_info_all();
    $itemsprinted = false;
    foreach ($sections as $k => $section) {
        $viewData = "";
        // prevent hidden sections in user activity. Thanks to Geoff Wilbert!
        if (!$section->uservisible) { continue;}
        // Check the section has modules/resources, if not there is nothing to display.
        if (empty($modinfo->sections[$k])) { continue;}
        // Check the section has display flag of modules, if not there is nothing to display.
        if( !is_section_display( $badgeid, $courseid, $section ) ){ continue;}

        $itemsprinted = true;
        $viewData.= "<div class='section' style='border: solid 1px #000000; margin: 20px; padding: 10px;'>";
        $viewData.= "<h2>";
        $viewData.= get_section_name($course, $section);
        $viewData.= "</h2>";
        $viewData.= "<div class='content' style='margin: 20px;'>";
        if ($mode === "outline") {
            $viewData.= "<table cellpadding=\"4\" cellspacing=\"0\">";
        }

        foreach ($modinfo->sections[$k] as $cmid) {
            $mod = $modinfo->cms[$cmid];

            if (empty($mod->uservisible)) {
                continue;
            }

            $instance = $DB->get_record("$mod->modname", array("id"=>$mod->instance));
            $libfile = "$CFG->dirroot/mod/$mod->modname/lib.php";

            if (!file_exists($libfile)) { continue;}

            switch ($mode) {
                case "outline":
                    $user_outline = $mod->modname."_user_outline";
                    if (function_exists($user_outline)) {
                        $output = $user_outline($course, $user, $mod, $instance);
                    } else {
                        $output = report_outline_user_outline($user->id, $cmid, $mod->modname, $instance->id);
                    }
                    report_outline_print_row($mod, $instance, $output);
                    break;
                case "complete":
                    $sectionid = $section->id;
                    $moduleid  = $mod->id;
                    if( !get_display( $badgeid, $courseid, $sectionid, $moduleid ) ){ continue; break;}
                    $user_complete = $mod->modname."_user_complete";
                    $image = $OUTPUT->pix_icon('icon', $mod->modfullname, 'mod_'.$mod->modname, array('class'=>'icon'));
                    $viewData.= "<h4>$image $mod->modfullname: ".
                         "<a href=\"$CFG->wwwroot/mod/$mod->modname/view.php?id=$mod->id\">".
                         format_string($instance->name,true)."</a></h4>";
                    ob_start();

                    $viewData.=  "<ul style='margin-left: 25px;'>";
                    if (function_exists($user_complete)) {
                        $user_complete($course, $user, $mod, $instance);
                    } else {
                        $viewData.= report_outline_user_complete($user->id, $cmid, $mod->modname, $instance->id);
                    }
                    $viewData.= "</ul>";

                    $output = ob_get_contents();
                    ob_end_clean();

                    if (str_replace(' ', '', $output) != '<ul></ul>') {
                        $viewData.=  "<ul style='margin-left: 25px;'>";
                        $viewData.= $output;
                        $viewData.= "</ul>";
                    }
                    break;
                }
            }

            if ($mode === "outline") {
                $viewData.= "</table>";
            }
            $viewData.= '</div>';  // content
            $viewData.= '</div>';  // section
            $viewDatas[] = $viewData;
    }    
    //--------------------------------------------------------------------------
    if( empty($viewDatas) ){ return false;}
    $detail_informs = json_safe_encode($viewDatas);
    $inform_title = get_string('detail_title', 'local_ku_badge_plugins');
    echo '
    <script type="text/javascript">
        function add_detail() {
            var detail_informs = '.$detail_informs.';
            var informs_title  = "'.$inform_title.'";

            var h3Tag2 = document.createElement("h3");
            h3Tag2.innerHTML = informs_title;

            var divTag2 = document.createElement("div");
            divTag2.id = "badge_add_detail_div_informs";
            divTag2.style = "margin: 20px;";
            var viewdata="";
            detail_informs.forEach(
                function viewArrayElements(value) {
                    viewdata += value;
                }
            );
            divTag2.innerHTML = viewdata;

            var divDetails = document.getElementById("badge_add_detail_display");
            divDetails.appendChild(h3Tag2);
            divDetails.appendChild(divTag2);
        }
        addOnload(add_detail);
    </script>
    ';
    return true;
}

function json_safe_encode($data){
    return json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
}

function this_add_report_nodes($userid, $nodeinfo){
    global $USER, $PAGE;
    $reportnode = null;
    $navigationnodeerror =
            'Could not find the navigation node requested. Please check that the node you are looking for exists.';
    if ($userid != $USER->id) {
        if(isset($PAGE->navigation)){
            $newusernode = $PAGE->navigation->find('user' . $userid, null);
            // Check that we have a valid node.
            if (empty($newusernode)) {
                // Throw an error if we ever reach here.
                throw new coding_exception($navigationnodeerror);
            }
            // Add 'Reports' to the user node.
            $reportnode = $newusernode->add(get_string('reports'));
        }
    } else {
        // We are looking at our own profile.
        // [settingsnav]�����åȤ���Ƥ��ʤ���
        if(isset($PAGE->settingsnav)){
            $myprofilenode = $PAGE->settingsnav->find('myprofile', null);
            // Check that we do end up with a valid node.
            if (empty($myprofilenode)) {
                // Throw an error if we ever reach here.
                throw new coding_exception($navigationnodeerror);
            }
            // Add 'Reports' to our node.
            $reportnode = $myprofilenode->add(get_string('reports'));
        }
    }
    // Finally add the report to the navigation tree.
    if(isset($reportnode)){
        $reportnode->add($nodeinfo['name'], $nodeinfo['url'], navigation_node::TYPE_COURSE);
    }    
}

function is_detail_in_course($badgeid) {
    global $CFG, $DB, $USER;
   
    if (empty($CFG->profileroles)) {
        return false;
    }

    $userid = $USER->id;
    $badgedat = $DB->get_record('badge', array('id'=>$badgeid), '*', MUST_EXIST);
    $courseid = $badgedat->courseid;

    if ($courseid == SITEID) {
        $context = context_system::instance();
    } else {
        $context = context_course::instance($courseid);
    }

    list($rallowed, $params) = $DB->get_in_or_equal(explode(',', $CFG->profileroles), SQL_PARAMS_NAMED, 'a');
    list($contextlist, $cparams) = $DB->get_in_or_equal($context->get_parent_context_ids(true), SQL_PARAMS_NAMED, 'p');
    $params = array_merge($params, $cparams);

    if ($coursecontext = $context->get_course_context(false)) {
        $params['coursecontext'] = $coursecontext->id;
    } else {
        $params['coursecontext'] = 0;
    }

    $sql = "SELECT DISTINCT r.id, r.name, r.shortname, r.sortorder, rn.name AS coursealias
              FROM {role_assignments} ra, {role} r
         LEFT JOIN {role_names} rn ON (rn.contextid = :coursecontext AND rn.roleid = r.id)
             WHERE r.id = ra.roleid
                   AND ra.contextid $contextlist
                   AND r.id $rallowed
                   AND ra.userid = :userid
          ORDER BY r.sortorder ASC";
    $params['userid'] = $userid;

    $rolenames = [];

    if ($roles = $DB->get_records_sql($sql, $params)) {
        $rolenames = role_fix_names($roles, $context, ROLENAME_ALIAS, true);   // Substitute aliases
        foreach ($rolenames as $roleid => $rolename) {
            //    echo "rolename=[".$roleid.": ".$rolename."]";
            if( $roleid==1 || $roleid==2 || $roleid==3 ) {
                return true;
            }
        }
    }
    return false;
}


/* --------------------
ku_badge_access_ctl
--------------------- */
function badge_access_display(){
    $id       = required_param('hash', PARAM_ALPHANUM);
    $issued_badge = new issued_badge($id);
    $userid   = $issued_badge->recipient->id;
    $badgeid  = $issued_badge->badgeid;
    $badge = new badge($badgeid);
    if( $badge->type != BADGE_TYPE_COURSE ){ return;}
    $accessmode = "1";
    $accesspass = "";
    
    global $DB, $USER;
    $dbman = $DB->get_manager();
    $accessctrl=$dbman->table_exists('badge_access_ctl');
   
    if( $userid == $USER->id ){ $accessmode = "1";}
    else if($accessctrl){
        // DB読込
        $accessdata = $DB->get_record_sql("SELECT ac.id, ac.badgeid, ac.userid, ac.accessmode, ac.accesspass
                                FROM {badge_access_ctl} ac WHERE ac.badgeid=$badgeid and ac.userid=$userid");
        if(!empty($accessdata)) {
            $accessmode = $accessdata->accessmode;
            $accesspass = $accessdata->accesspass;
        }
    }
    if( $accessmode=="2" ) {
        add_access_password( $badgeid, $userid );
    }
}

function add_access_password( $badgeid, $userid )
{
    $inppass_title = get_string('inppass_title', 'local_ku_badge_plugins');
    $actionUrl = new moodle_url('/local/ku_badge_plugins/classes/access_ctl_action.php');
    
    echo '
    <script type="text/javascript">
        function OnbtnUnlock(){
            var userid = "'.$userid.'";
            var badgeid= "'.$badgeid.'";
            var edtTag = document.getElementById("id_detail_edtpass");
            var accesspass = edtTag.value;
            onClickCheck( badgeid, userid, "2", accesspass );
        }

        function add_access_password() {
            var inppass_title  = "'.$inppass_title.'";
            var divTagInppass = document.createElement("div");
            divTagInppass.id = "badge_add_inputpassword";
            divTagInppass.style.display = "block";

            var h4Tag1 = document.createElement("h4");
            h4Tag1.innerHTML = inppass_title;
            divTagInppass.appendChild(h4Tag1);

            var divTag1 = document.createElement("div");
            divTag1.id = "badge_add_detail_divinppass";
            divTag1.style = "margin: 0px 20px;";
            divTag1.innerHTML = "'.get_string('inppass_edit','local_ku_badge_plugins').'";

            var edtTag1 = document.createElement("input");
            edtTag1.type = "password";
            edtTag1.id   = "id_detail_edtpass";
            edtTag1.name = "nm_detail_edtpass";
            edtTag1.value= "";

            var btnTag1 = document.createElement("input");
            btnTag1.type = "button";
            btnTag1.id   = "id_detail_btnpass";
            btnTag1.name = "nm_detail_btnpass";
            btnTag1.value= "'.get_string('inppass_button','local_ku_badge_plugins').'";
            var fnc = new Function("OnbtnUnlock();");
            btnTag1.onclick = fnc;

            divTag1.appendChild(edtTag1);
            divTag1.appendChild(btnTag1);
            divTagInppass.appendChild(divTag1);
            divTagInppass.style.display = "block";

            var divDetails = document.getElementById("badge-details");
            divDetails.appendChild(divTagInppass);
        }
        addOnload(add_access_password);
    </script>
    ';
    
    echo '
    <script type="text/javascript">
        function onClickCheck( badgeid, usrid, accessmode, accesspass ) {
            $.ajax({
                   type: "POST",
                   url: "'.$actionUrl.'",
                   dataType: "html",
                   data: {
                       "check_badgeid"   : badgeid,
                       "check_userid"    : usrid,
                       "check_accessmode": accessmode,
                       "check_accesspass": accesspass,
                   },
                   success: function(post) {
                       console.log("CHECK SUCCESS:" + post);
                        var divTag = document.getElementById("badge_add_inputpassword");
                        var divCmt = document.getElementById("badge_add_comment_display");
                        var divInf = document.getElementById("badge_add_detail_display");
                        if(post==="OK" ) {
                            if(divCmt!==null){
                                console.log("COMMENT DISPLAY ON");
                                divCmt.style.display = "block";
                            }
                            if(divInf!==null){ divInf.style.display = "block";}
                            divTag.style.display = "none";
                        }
                   },
                   error:   function(post) {
                       alert("ERROR:" + post);
                   },
                   complete: function(post) {
                       //alert("COMPLETE:" + post);
                   }
            });
        }
    </script>';
    return true;
}

