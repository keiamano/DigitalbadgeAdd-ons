<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.



$string['c_pluginname'] = 'バッジコメント設定';
$string['c_tab_title'] = 'コメント';
$string['user_name'] = '姓　名';
$string['comment_edit'] = 'コメント編集';
$string['comment'] = 'コメント';
$string['csv_btn_name'] = 'CSVから一括登録';
$string['csv_file_failed']= '【ファイルデータ異常】';
$string['csv_notfound_1'] = 'ユーザ名[';
$string['csv_notfound_2'] = ']が見つかりませんでした。';
$string['csv_checkfile']  = 'ファイルを確認してください。';
$string['csv_notupload']  = 'ファイルがアップロードされませんでした。';
$string['csv_notselected']='ファイルが選択されていません。';
$string['edit'] = '編集';
$string['save'] = '保存';
$string['comment_title'] = "バッジ発行者からのコメント";


$string['d_pluginname']   = 'バッジ詳細追加';
$string['d_tab_title']    = '表示選択';
$string['checkupdate']  = '保存する';
$string['detail_title'] = '関連する学習成果物';


$string['a_pluginname'] = 'バッジアクセス権限設定';
$string['add_button_name'] = 'アクセス権限の変更';
$string['inppass_title'] = 'パスワードロック';
$string['inppass_edit'] = '入力欄：';
$string['inppass_button'] = 'ロック解除';


$string['item_title'] = 'バッジ閲覧履歴';
$string['pluginname'] = '熊大バッジ統合プラグイン';
