<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


$string['c_pluginname'] = 'Badge Comment Set';
$string['c_tab_title'] = 'comment';
$string['user_name'] = 'user name';
$string['comment_edit'] = 'comment edit';
$string['comment'] = 'comment';
$string['csv_btn_name'] = 'Add for CSV';
$string['csv_file_failed']= '[CSV file data error]';
$string['csv_notfound_1'] = 'user name[';
$string['csv_notfound_2'] = '] is not found.';
$string['csv_checkfile']  = 'Please check CSV file.';
$string['csv_notupload']  = 'CSV file can not upload.';
$string['csv_notselected']= 'Please select CSV file.';
$string['edit'] = 'Edit';
$string['save'] = 'Save';
$string['comment_title'] = 'Comment from badge issuer';


$string['d_pluginname'] = 'Badge Add Detail';
$string['d_tab_title']  = 'Select View Item';
$string['checkupdate']= 'Save the setting';
$string['detail_title'] = 'Related to the results of learning';


$string['a_pluginname'] = 'Badge Access Control';
$string['add_button_name'] = 'Change access authority';
$string['inppass_title'] = 'Please Input Password';
$string['inppass_edit'] = 'Edit Box';
$string['inppass_button'] = 'Checking';

$string['item_title'] = 'Badge Browsing History';
$string['pluginname'] = 'Kumamoto Uni. badge plugins';
