<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');
require_once($CFG->libdir . '/badgeslib.php');
require_once($CFG->libdir . '/filelib.php');

/**
 * Form to display badge comments.
 *
 */
class comment_display_form extends moodleform {
    /**
     * Defines the form
     */
    /**************************************************************************/
    public function definition() {
        global $DB,$OUTPUT,$PAGE,$CFG;
        $mform   = $this->_form;
        $badge   = $this->_customdata['badge'];
        $badgeid = $this->_customdata['badgeid'];
        $sortby  = $this->_customdata['sortby'];
        $sorthow = $this->_customdata['sorthow'];
        $action  = $this->_customdata['action'];

        $uploadCommentUrl = new moodle_url('/local/ku_badge_plugins/classes/comment_action.php');
        $loadCSV  = "";
        $loadCSV .= html_writer::start_tag('div',
                array('class' => 'form-buttons',
                      'style' => "background-color: #E0F0E0;"
                    ));
        $loadCSV .= html_writer::start_tag('fieldset',
                array(  'class' => 'upload-csv-field',
                        'align' => 'left',
                        'style' => "border:2px solid #E0F0E0; padding: 0 30px;"
                    ));
        $loadCSV .= html_writer::tag('legend', get_string('csv_btn_name', 'local_ku_badge_plugins'),
                array(  'align' => 'top',
                        'style' => "border:4px double #0000FF; width: 150px; font-size: 1.1em; padding: 0 40px;"
                    ));
        $loadCSV .= html_writer::empty_tag('input',
                array(  'type'    => 'file',
                        'id'      => 'id_csvBtn',
                        'accept'  => '.csv',
                        'name'    => 'csv_file_open'
                    ));
        $loadCSV .= html_writer::empty_tag('input',
                array(  'class' => 'btn btn-primary form-submit',
                        'type'  => 'submit',
                        'name'  => 'comment_update',
                        'disabled'=>'disabled',
                        'value' => get_string('csv_btn_name', 'local_ku_badge_plugins')
                    ));
        $loadCSV .= html_writer::empty_tag('input',
                array(  'type'  =>'hidden',
                        'id'    =>'id_csv_file_dir',
                        'value' =>$CFG->dataroot,
                        'uploadCommentUrl'  => $uploadCommentUrl,
                        'badgeidForComment' => $badgeid
                    ));
        $loadCSV .= html_writer::end_tag('fieldset');
        $loadCSV .= html_writer::end_tag('div');
   
        echo $OUTPUT->box( $loadCSV, 'statusbox');// statusbox clearfix mdl-align');

        $btnStrEdit = get_string('edit', 'local_ku_badge_plugins');
        $btnStrSave = get_string('save', 'local_ku_badge_plugins');
        
        $sql  = "";
        $sql .= " SELECT";
        $sql .= "   u.*, b.userid, b.dateissued, c.badge_comment";
        $sql .= " FROM {user} u";
        $sql .= "   INNER JOIN {badge_issued} b ON b.badgeid = $badgeid AND b.userid = u.id";
        $sql .= "   LEFT JOIN {badge_comment} c ON c.badgeid = $badgeid AND c.userid = u.id";
        $sql .= " WHERE b.badgeid = $badgeid AND u.deleted = 0";
        $sql .= " ORDER BY $sortby $sorthow";
        $rs = $DB->get_recordset_sql($sql);
        
        $comment_datas = array();
        foreach ($rs as $comment) {
            $comment_datas[] = $comment;
        }
        $rs->close();
        $data = array();
        foreach ($comment_datas as $comment) {
            $username = $comment->lastname.' '.$comment->firstname;
            $userid   = $comment->userid;
            $usertext = $comment->badge_comment;

            $btnAttr  = array(
                'type'    => 'button',
                'id'      => 'id_editBtn-'.$userid,
                'class'   => 'btn btn-secondary',
                'onclick' => 'onClickBtn("'.$badgeid.'","'.$userid.'");',
                'value'   => $btnStrEdit
            );
            $editBtn = html_writer::tag('input', '', $btnAttr);
            
            $textAttr = array(
                'name'    => 'nm_textBox-'.$userid,
                'id'      => 'id_textBox-'.$userid,
                'cols'    => '100%',
                'rows'    => '3',
                'class'   => 'markingguideremark form-control',
                'readonly' => 'readonly'
            );
            $textBox = html_writer::tag('textarea', $usertext,$textAttr);

            $useridAttr  = array(
                'type'    => 'hidden',
                'id'      => 'id_userid-'.$userid,
                'value'   => $userid
            );
            $useridPrm = html_writer::tag('input', '', $useridAttr);

            $data[] = array(
                $username,
                $editBtn,
                $textBox,
                $useridPrm
            );
        }

        $table = new html_table();
        $table->attributes['class'] = 'generaltable boxaligncenter boxwidthwide';
        $table->head = array(
            get_string('user_name',    'local_ku_badge_plugins'),
            get_string('comment_edit', 'local_ku_badge_plugins'),
            get_string('comment',      'local_ku_badge_plugins'),
        );
        $table->data  = $data;
        $mform->addElement('html', html_writer::table($table));
        
        $actionUrl = new moodle_url('/local/ku_badge_plugins/classes/comment_action.php');
        echo '
        <script type="text/javascript">
            function onClickBtn( badgeId, usrId ) {
                var editBtn = document.getElementById("id_editBtn-" + usrId);
                var textBox = document.getElementById("id_textBox-" + usrId);
                var btnStrEdit = "'.$btnStrEdit.'";
                var btnStrSave = "'.$btnStrSave.'";
                if( textBox.readOnly == true ) {
                    editBtn.value    = btnStrSave;
                    textBox.readOnly = false;
                }
                else {
                    editBtn.value    = btnStrEdit;
                    textBox.readOnly = true;
                    onClickSave( badgeId, usrId, textBox.value );
                }
            }

            function onClickSave( badgeid, usrid, usrComment ) {
                $.ajax({
                        type: "POST",
                        url: "'.$actionUrl.'",
                        dataType: "html",
                        data: {
                            "save_badgeid": badgeid,
                            "save_userid" : usrid,
                            "save_comment": usrComment,
                        },
                        success: function(post) {
                            //console.log("COMMENT SAVE SUCCESS:" + post);
                        },
                        error:   function(post) {
                            alert("COMMENT SAVE ERROR:" + post);
                        },
                        complete: function(post) {
                            console.log("COMMENT SAVE COMPLETE:" + post);
                        }
                });
            }
        </script>
        ';
    }  
}

function badge_comment_tab_add( $active ){
    $tab_title = get_string('c_tab_title', 'local_ku_badge_plugins');
    $tabUrl = new moodle_url('/local/ku_badge_plugins/comment.php');
    $badgeid = optional_param('id', true, PARAM_INT);
    $badge = new badge($badgeid);
    $context = $badge->get_context();
    if( !has_capability('moodle/badges:configurecriteria', $context) ) { return false;}
    if( $badge->type != BADGE_TYPE_COURSE ) { return false;}

    echo '
    <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/external/jquery/jquery.js').'"></script>
    <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.js').'"></script>
    <link type="text/css" rel="stylesheet" href="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.css').'" />
    <script type="text/javascript">
        function addOnload(func) {
            try {
                window.addEventListener("load", func, false);
            } catch(e) {
                window.attachEvent("onload", func);
            }
        }
    </script>
    ';
    echo '
    <script type="text/javascript">
        function add_tab() {
            var active = '.$active.';
            var li_element = document.createElement("li");
            if( active ) { li_element.className = "active nav-item";}
            var a_element = document.createElement("a");
            a_element.className = "nav-link";
            if( !active ){
                li_element.className = "nav-item";
                a_element.title = "'.$tab_title.'";
                a_element.href  = "'.$tabUrl.'?id='.$badgeid.'";
            }
            a_element.appendChild(document.createTextNode("'.$tab_title.'"));

            tabElms = document.getElementById("id_tab_add1");
            var objUl = document.getElementsByClassName("nav nav-tabs")[0];

            if(typeof objUl !== "undefined"){
                if( !tabElms ) {
                    li_element.appendChild(a_element);
                    li_element.id = "id_tab_add1";
                    objUl.appendChild(li_element);
                }
                else {
                    if( active ) { tabElms.className="active nav-item";}
                    tabElms.appendChild(a_element);
                }
            }
        }
        addOnload(add_tab);
    </script>
    ';
    return true;
}
