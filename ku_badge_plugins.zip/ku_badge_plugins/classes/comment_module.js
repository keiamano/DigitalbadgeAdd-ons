$(document).on('change','input[name="csv_file_open"]', function(){
    console.log("click: input[name=csv_file_open]");
    var uploadCommentFile= $('input[name="csv_file_open"]').val();
    console.log("FILENAME : "+uploadCommentFile);

    var reg=/(.*)(?:\.([^.]+$))/;
    var ext= uploadCommentFile.match(reg)[2];
    if( ext.toUpperCase() != 'CSV' ) {
        uploadCommentFile = '';
        $('input[name="csv_file_open"]').val('');
    }

    if( uploadCommentFile!=='') {
        $('input[name="comment_update"]').prop("disabled", false);
    }
    else {
        $('input[name="comment_update"]').prop("disabled", true);
    }
    return;
});

$(document).on('click','input[name="comment_update"]', function(){
    console.log( "click:input[name=comment_update]" );
    var fd = new FormData();
    var uploadCommentUrl = $('input[id="id_csv_file_dir"]').attr('uploadCommentUrl');
    var uploadCommentPath= $("#id_csv_file_dir").val();
    var uploadBadgeid    = $('input[id="id_csv_file_dir"]').attr('badgeidForComment');
    var uploadCommentFile= $('input[name="csv_file_open"]').val();
    console.log("FILENAME : "+uploadCommentFile);
    console.log("FILETYPE : "+$("input[name='csv_file_open']").prop("files")[0]);
    console.log("URL      : "+uploadCommentUrl);
    console.log("BADGEID  : "+uploadBadgeid);
    console.log("UP PATH  : "+uploadCommentPath);

    if (uploadCommentFile === '') {
        alert("Please check a file for the badge comments.");
        return;
    }

    fd.append( "csvcomment_dir" , uploadCommentPath );
    fd.append( "csvcomment_file", $("input[name='csv_file_open']").prop("files")[0] );
    fd.append( "csvcomment_badgeid", uploadBadgeid );
    var postData = {
      type        : "POST",
      dataType    : "text",
      data        : fd,
      processData : false,
      contentType : false
    };
    $.ajax(
      uploadCommentUrl, postData
    ).done(function( res ){
        if( res === 'OK') {
            console.log( "DONE:OK" );
            window.location.reload();
        }
        else {
            console.log( "DONE:NG"+res );
            alert( res );
        }
    });
    $('input[name="csv_file_open"]').val('');
    $('input[name="comment_update"]').prop("disabled", true);
    $(this).closest('form').submit();
});
