<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->libdir . '/badgeslib.php');
require_once($CFG->libdir . '/filelib.php');


function badge_access_ctl_btn_add(){
    global $CFG, $USER;
    $btn_name = get_string('add_button_name', 'local_ku_badge_plugins');
    $id = required_param('hash', PARAM_ALPHANUM);
    $badge = new issued_badge($id);
    if( $badge->recipient->id != $USER->id ) {
        // 自分自身のバッジの時のみ表示する。
        return;
    }
    $userid = $badge->recipient->id;
    $badgeid= $badge->badgeid;
    //moodle_urlの引数で設定しようとすると文字化けする。
    //$argphp= array('id' => $badge->recipient->id, 'badgeid' => $badge->badgeid);
    //$dialog_src = new moodle_url( "/local/ku_badge_plugins/access_ctl.php", $argphp );
    $dialog_src = new moodle_url( "/local/ku_badge_plugins/access_ctl.php" );
    $dialog_src.= '?hash='.$id;
    $actionUrl  = new moodle_url('/local/ku_badge_plugins/classes/access_ctl_action.php');
    echo '
        <script type="text/javascript">
        function add_button() {
            var btn_element = document.createElement("input");
            btn_element.type = "button";
            btn_element.name = "bg_access_ctl_btn";
            btn_element.id = "bg_access_ctl_btn";
            btn_element.className = "btn btn-secondary";
            btn_element.value = "'.$btn_name.'";
            var f = new Function("access_ctl();");
            btn_element.onclick = f;

            var div_btnelement = document.createElement("div");
            div_btnelement.style = "padding-top: 5px;";
            div_btnelement.appendChild(btn_element);

            var objHtml = document.getElementById("badge-image");
            objHtml.appendChild(div_btnelement);


            var div_element = document.createElement("div");
            div_element.id    = "modal-content";
            div_element.className = "dialog";
            div_element.title = "'.$btn_name.'";
            div_element.style = "display: none; position: relative; width: 98%; padding-top: 200px; background-color: #f0f0f0;";

            var iframe_element = document.createElement("iframe");
            iframe_element.id  = "modal_frame";
            iframe_element.name= "modal_frame";
            iframe_element.src = "'.$dialog_src.'";
            iframe_element.style = "position: absolute; top: 0; left: 0; width: 99%; height: 80%; background-color: #fff;";
            iframe_element.frameborder = "0";
            //iframe_element.border = "none";
            div_element.appendChild(iframe_element);

            var divbtn_element = document.createElement("div");
            divbtn_element.id = "divbtn_element";
            divbtn_element.style="text-align: center;";
           
            var okbtn_element = document.createElement("input");
            okbtn_element.type = "button";
            okbtn_element.name = "dialog-ok";
            okbtn_element.id = "id_access_dialog-ok";
            okbtn_element.className = "btn btn-secondary";
            okbtn_element.value = "O K";
            okbtn_element.title = "OK";
            okbtn_element.style = "margin: 0px 5px; padding-left: 22px; padding-right: 22px; autocomplete: off;";
            var fok = new Function("access_OK();");
            okbtn_element.onclick = fok;
            divbtn_element.appendChild(okbtn_element);

            var clbtn_element = document.createElement("input");
            clbtn_element.type = "button";
            clbtn_element.name = "dialog-cancel";
            clbtn_element.id = "id_access_dialog-cancel";
            clbtn_element.className = "btn btn-secondary";
            clbtn_element.value= "Cancel";
            clbtn_element.title= "Cancel";
            clbtn_element.style= "margin: 0px 10px; padding-left: 10px;";
            var fcl = new Function("access_CANCEL();");
            clbtn_element.onclick = fcl;
            divbtn_element.appendChild(clbtn_element);

            div_element.appendChild(divbtn_element);
            
            var body_element = document.getElementsByTagName("body")[0];
            body_element.appendChild(div_element);
            $("#modal-content").dialog({
                width: "350px",
                show : "fade",
                hide : "fade",
                resizable: false,
                draggable: false,
                autoOpen: false,
                modal: true
            });
        }
    
        addOnload(add_button);

        function access_ctl() {
            var iframe = document.getElementById("modal_frame");
            iframe.contentDocument.location.replace("'.$dialog_src.'");
            $("#modal-content").dialog("open");
            $(".ui-widget-overlay").css({"opacity" : "0.5", "background-color" : "rgba(0,0,0,0.5)" });        
        }
        
        function access_OK() {
            if( upload_accessmode()==true ) {
                $("#modal-content").dialog("close");
            }
        }
        
        function access_CANCEL() {
            $("#modal-content").dialog("close");
        }
        
        function upload_accessmode(){
            var badgeid = '.$badgeid.';
            var userid  = '.$userid.';
            var accessmode=0;
            var accesspass="";
            var radiobtn0 = modal_frame.document.getElementById("id_radio-access0");
            var radiobtn1 = modal_frame.document.getElementById("id_radio-access1");
            var radiobtn2 = modal_frame.document.getElementById("id_radio-access2");
            var textpass  = modal_frame.document.getElementById("id_access-pass");
            if( radiobtn0!=null && radiobtn0.checked ){ accessmode = 0;}
            else if( radiobtn1!=null && radiobtn1.checked ){ accessmode = 1;}
            else if( radiobtn2!=null && radiobtn2.checked && textpass.value.length ){
                accessmode = 2;
                accesspass = textpass.value;
            }
            else{ return false;}
            
            // console.log("accessmode=["+accessmode+"] accesspass=["+accesspass+"]");
            onClickSave( badgeid, userid, accessmode, accesspass );
            return true;
        }
        
        function onClickSave( badgeid, usrid, accessmode, accesspass ) {
           $.ajax({
                   type: "POST",
                   url: "'.$actionUrl.'",
                   dataType: "html",
                   data: {
                       "save_badgeid"   : badgeid,
                       "save_userid"    : usrid,
                       "save_accessmode": accessmode,
                       "save_accesspass": accesspass
                   },
                   success: function(post) {
                       //alert("SUCCESS:" + post);
                   },
                   error:   function(post) {
                       alert("ERROR:" + post);
                   },
                   complete: function(post) {
                       //alert("COMPLETE:" + post);
                   }
           });
        }
    </script>
    ';    
}

function check_badge_access_ctl(){
	global $DB, $USER;
	
	$id = required_param('hash', PARAM_ALPHANUM);
	$badge = new issued_badge($id);
	
	if( $badge->recipient->id != $USER->id ) {
        // 自分自身のバッジの時のみチェックする。
        return;
    }
    
    $userid  = $badge->recipient->id;
	$badgeid = $badge->badgeid;
    // DB読込
	$accessdata = $DB->get_record_sql("SELECT ac.id, ac.badgeid, ac.userid, ac.accessmode, ac.accesspass
                        FROM {badge_access_ctl} ac WHERE ac.badgeid=$badgeid and ac.userid=$userid");
                        
	if(!$accessdata){
		echo '
        	<script type="text/javascript">
        		addOnload(access_ctl);
        	</script>
    	'; 
	}
}
