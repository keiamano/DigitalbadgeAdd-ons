<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');
require_once($CFG->libdir . '/badgeslib.php');
require_once($CFG->libdir . '/filelib.php');

/**
 * Form to display badge comments.
 *
 */
class detail_setting_form extends moodleform {
    /**
     * Defines the form
     */
    /**************************************************************************/
    public function definition() {
        global $DB,$OUTPUT,$PAGE,$CFG,$USER;
        $mform   = $this->_form;
        $badge   = $this->_customdata['badge'  ];
        $badgeid = $this->_customdata['badgeid'];
        $sortby  = $this->_customdata['sortby' ];
        $sorthow = $this->_customdata['sorthow'];
        $action  = $this->_customdata['action' ];
        $courseid= $badge->courseid;
        if($courseid<=0){ return;}

        $checkupdate = get_string('checkupdate', 'local_ku_badge_plugins');
        $course = $DB->get_record('course', array('id'=>$courseid), '*', MUST_EXIST);
        $modinfo = get_fast_modinfo($course);
        $mods = $modinfo->get_cms();
        $sections = $modinfo->get_section_info_all();
        
        $viewData = "";
        $viewData.= html_writer::start_tag('div', array('class' => 'btn-group'));
        $viewData.= html_writer::tag('input', "", array('type' => 'button', 'id' => 'checkallonpage',
            'class' => 'btn btn-secondary', 'value' => get_string('selectall')));
        $viewData.= html_writer::tag('input', "", array('type' => 'button', 'id' => 'checknone',
            'class' => 'btn btn-secondary', 'value' => get_string('deselectall')));
        $viewData.= html_writer::tag('input', "", array('type' => 'button', 'id' => 'checkupdate',
            'class' => 'btn btn-secondary', 'style'=>'margin-left: 30px;', 'value' => $checkupdate));
        $viewData.= html_writer::end_tag('div');
        $viewDatas[] = $viewData;
        $viewDatas[].= html_writer::tag( 'h3', $course->fullname );
        
        $itemsprinted = false;
        foreach ($sections as $k => $section) {
            $viewData = "";
            if (!$section->uservisible) { continue;}
            if (empty($modinfo->sections[$k])) { continue;}
            $itemsprinted = true;
            $viewData.= html_writer::start_tag('div', array('class'=>'section', 'style'=>'border: solid 1px #000000; margin: 20px; padding: 10px;'));
            //$viewData.= "<input type='checkbox' class='sectioncheckbox'>";
            $viewData.= html_writer::tag( 'h4', get_section_name($course, $section) );
            $viewData.= html_writer::start_tag('div', array('class'=>'content', 'style'=>'margin: 20px;'));
            foreach ($modinfo->sections[$k] as $cmid) {
                $mod = $modinfo->cms[$cmid];
                if (empty($mod->uservisible)) {
                    continue;
                }

                $instance = $DB->get_record("$mod->modname", array("id"=>$mod->instance));
                $libfile = "$CFG->dirroot/mod/$mod->modname/lib.php";
                if (!file_exists($libfile)) { continue;}
                
                $sectionid = $section->id;
                $moduleid  = $mod->id;
                $modvisible= $mod->uservisible;
                $modstring = $mod->modfullname.':'.$instance->name;
                $saveUrl   = new moodle_url('/local/ku_badge_plugins/classes/detail_action.php');
                $checked   = get_display( $badgeid, $courseid, $sectionid, $moduleid );
                $viewData.= html_writer::start_tag('ul');
                $boxparams = array(
                    'type'      => 'checkbox',
                    'class'     => 'usercheckbox',
                    'id'        => 'id_'.$sectionid.'_'.$moduleid,
                    'name'      => 'nm_'.$sectionid.'_'.$moduleid,
                    'badgeid'   => $badgeid,
                    'courseid'  => $courseid,
                    'sectionid' => $sectionid,
                    'moduleid'  => $moduleid,
                    'modvisible'=> $modvisible,
                    'saveUrl'   => $saveUrl );
                if( $checked ) { $boxparams['checked'] = 'checked';} 
                $viewData.= html_writer::empty_tag('input', $boxparams);
                $viewData.= $modstring;
                //$viewData.= "<input type='hidden' name='id' value=".$course->id." />";
                $viewData.= html_writer::end_tag('ul');
            }
            $viewData.= html_writer::end_tag('div');  // content
            $viewData.= html_writer::end_tag('div');  // section
            $viewDatas[] = $viewData;
        }    
        //--------------------------------------------------------------------------
        $detail_informs="";
        foreach ($viewDatas as $vdata) {
            $detail_informs.= $vdata;
        }
        echo $detail_informs;
        $moduleFile = new moodle_url('/local/ku_badge_plugins/classes/detail_module.js');
        $module = array('name' => 'add_detail', 'fullpath' => $moduleFile );
        $PAGE->requires->jquery();
        $PAGE->requires->js( $moduleFile );
        $PAGE->requires->js_init_call('M.add_detail.init_participation', null, false, $module);
    }
}

function get_display( $badgeid, $courseid, $sectionid, $moduleid ){
    global $DB;
    $checked = 1;
    $dbman = $DB->get_manager();
    if( !$dbman->table_exists('badge_detail')     ) { return $checked;}
    if( ($DB->count_records('badge_detail')-1)<=0 ) { return $checked;}
    $disp = $DB->get_record('badge_detail',
                        array(  'badgeid'  =>$badgeid,
                                'courseid' =>$courseid,
                                'sectionid'=>$sectionid,
                                'moduleid' =>$moduleid),
                        '*');
    if( $disp == false                     ) { return $checked;}
    if( !empty($disp) && $disp->display==1 ) { $checked = 1;}
    else                                     { $checked = 0;}
    return $checked;
}

function is_section_display( $badgeid, $courseid, $section ){
    $displayon = false;
    if( empty($section->sequence) ){ return $displayon;}
    
    foreach (preg_split('/,/', $section->sequence, -1, PREG_SPLIT_NO_EMPTY) as $cmid) {
        if( empty($cmid) ){ continue;}
        if( get_display( $badgeid, $courseid, $section->id, $cmid ) ){
            $displayon = true;
            break;
        }
    }

    return $displayon;
}

function badge_detail_tab_add( $active ){
    $tab_title = get_string('d_tab_title', 'local_ku_badge_plugins');
    $tabUrl = new moodle_url('/local/ku_badge_plugins/detail.php');
    $badgeid = optional_param('id', true, PARAM_INT);
    $badge = new badge($badgeid);
    $context = $badge->get_context();
    if( !has_capability('moodle/badges:configurecriteria', $context) ) { return false;}
    if( $badge->type != BADGE_TYPE_COURSE ) { return false;}

    echo '
    <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/external/jquery/jquery.js').'"></script>
    <script type="text/javascript" src="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.js').'"></script>
    <link type="text/css" rel="stylesheet" href="'.new moodle_url('/local/ku_badge_plugins/js/jquery-ui.min.css').'" />
    <script type="text/javascript">
        function addOnload(func) {
            try {
                window.addEventListener("load", func, false);
            } catch(e) {
                window.attachEvent("onload", func);
            }
        }
    </script>
    ';
    echo '
    <script type="text/javascript">
        function add_tab() {
            var active = '.$active.';
            console.log("active="+active);
            var li_element = document.createElement("li");
            if( active ) { li_element.className = "active nav-item";}
            var a_element = document.createElement("a");
            a_element.className = "nav-link";
            if( !active ){
                li_element.className = "nav-item";
                a_element.title = "'.$tab_title.'";
                a_element.href  = "'.$tabUrl.'?id='.$badgeid.'";
            }
            a_element.appendChild(document.createTextNode("'.$tab_title.'"));

            tabElms = document.getElementById("id_tab_add1");
            var objUl = document.getElementsByClassName("nav nav-tabs")[0];

            if(typeof objUl !== "undefined"){
                if( !tabElms ) {
                    var add_element = document.createElement("li");
                    add_element.id = "id_tab_add1";
                    objUl.appendChild(add_element);
                    li_element.appendChild(a_element);
                    objUl.appendChild(li_element);
                }
                else {
                    li_element.appendChild(a_element);
                    objUl.appendChild(li_element);
                }
            }
        }    
        addOnload(add_tab);
    </script>
    ';

    return true;
}


