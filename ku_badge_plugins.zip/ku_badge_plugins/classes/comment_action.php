<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

//defined('MOODLE_INTERNAL') || die(); これを入れると動かない
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/badgeslib.php');
require_once(__DIR__ . '/../lib.php');

//Ajaxによるリクエストかどうかの識別を行う
//strtolower()を付けるのは、XMLHttpRequestやxmlHttpRequestで返ってくる場合があるため
if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){  
    if (isset($_POST['save_badgeid'])){
        $badgeid = $_POST["save_badgeid"];
        $userid  = $_POST["save_userid"];
        $comment = $_POST["save_comment"];
        
        save_badge_comment( $badgeid, $userid, $comment );
        
        echo "\n"."DONE";
        echo "\n"."Badgeid:[$badgeid]"."\n"."Userid:[$userid]"."\n"."Comment:[$comment]";
    }
    else if( $_POST["csvcomment_dir"]){
        $echoStr = "OK";
        $dir = $_POST["csvcomment_dir"];
        $badgeid = $_POST["csvcomment_badgeid"];
        if( is_uploaded_file( $_FILES["csvcomment_file"]["tmp_name"] ) ){
            list($file_name,$file_type) = explode(".",$_FILES['csvcomment_file']['name']);
            //ファイル名を日付と時刻にしている。
            $name = date("YmdHis").".".$file_type;
            $file = $dir;
            $fileName = $file."/".$name;

            //ディレクトリを作成してその中にアップロードしている。
            if(!file_exists($file)){
// 2017.12.19 S.Miyamoto CHG START >> 書き込み権限付きでディレクトリを作成する
//                mkdir($file,0755,true);
                mkdir($file,0766,true);
// 2017.12.19 S.Miyamoto CHG END   <<
            }
            if(move_uploaded_file($_FILES['csvcomment_file']['tmp_name'], $fileName)) {
                chmod($fileName, 0644);

                // 読み込んだSJISのデータをUTF-8に変換して保存
                $fileData = file_get_contents($fileName);
                $charset  = get_charset_str($fileData);
                if( $charset != null ){
                    $convData = mb_convert_encoding($fileData, 'UTF-8', $charset);
                    file_put_contents($fileName, $convData);
                }
                else {
                    echo 'NG: unknown char set of file.';
                    return;
                }
                $csv = new SplFileObject( $fileName, 'r' );
                $csv->setFlags(SplFileObject::READ_CSV);

                $header = [];
                foreach ($csv as $row) {
                    if ($row === [null]){ continue;} // 最終行の処理
                    if (empty($header)) {
                        $header = $row;
                        continue;
                    }
                    $data[] = array_combine($header, $row);
                }
                unset( $csv );
                
                $sql = "";
                $sql .= " SELECT";
                $sql .= "   u.*, b.userid, b.dateissued, c.badge_comment";
                $sql .= " FROM {user} u ";
                $sql .= "   INNER JOIN {badge_issued} b ON b.badgeid = $badgeid AND b.userid = u.id";
                $sql .= "   LEFT JOIN {badge_comment} c ON c.badgeid = $badgeid AND c.userid = u.id";
                $sql .= " WHERE b.badgeid = $badgeid AND u.deleted = 0";
                $rs = $DB->get_recordset_sql($sql);
                $comment_datas = array();
                foreach ($rs as $cmmdat) {
                    $comment_datas[] = $cmmdat;
                }
                $rs->close();

                $add_comment = [];
                foreach ( $data as $dat ) {
                    $username    = trim($dat[$header[0]]);
                    $commentdata = trim($dat[$header[1]]);
                    $userid = 0;
                    foreach ( $comment_datas as $cmmdat ){
                        if( $username != $cmmdat->username ){ continue;}
                        $userid = $cmmdat->userid;
                        break;
                    }
                    if( $userid != 0 ){
                        $add_comment[] = array( 'userid' => $userid, 'comment' => $commentdata );
                        continue;
                    }
                    
                    if($echoStr=='OK'){ $echoStr = get_string('csv_file_failed','local_ku_badge_plugins')."\n";}
                    $echoStr .= get_string('csv_notfound_1','local_ku_badge_plugins').$dat[$header[0]].get_string('csv_notfound_2','local_ku_badge_plugins')."\n";
                }
                if($echoStr=="OK"){
                    foreach( $add_comment as $add_cmm ){
                        save_badge_comment( $badgeid, $add_cmm['userid'], $add_cmm['comment'] );
                    }
                }
                else {
                    $echoStr .= get_string('csv_checkfile','local_ku_badge_plugins');
                }
                unlink($fileName);
                //unlinkRecursive($dir, false);
            }
            else {
                $echoStr = get_string('csv_notupload','local_ku_badge_plugins');
            }
        }
        else {
            $echoStr = get_string('csv_notselected','local_ku_badge_plugins');
        }
        echo $echoStr;
    }
    else {
        echo 'NG';
    }
}else{
    echo 'This access is not valid.';
    die();
}

function save_badge_comment( $badgeid, $userid, $comment )
{
    global $DB, $USER;
    $comment_table = $DB->get_record('badge_comment', array('badgeid'=>$badgeid, 'userid'=>$userid));
    if( false == $comment_table ) {
        //echo "\n"."INSERT";
        $comment_table = new stdClass();
        $comment_table->badgeid       = $badgeid;
        $comment_table->userid        = $userid;
        $comment_table->badge_comment = $comment;
        $comment_table->timecreated   = time();
        $comment_table->timemodified  = time();
        $comment_table->createdby     = $USER->id;
        $comment_table->modifiedby    = $USER->id;
        $comment_table->id = $DB->insert_record('badge_comment', $comment_table);
    }
    else {
        //echo "\n"."UPDATE";
        $comment_table->badge_comment = $comment;
        $comment_table->timemodified  = time();
        $comment_table->modifiedby    = $USER->id;
        $DB->update_record('badge_comment', $comment_table);
    }    
}

function get_charset_str( $str ){
    foreach(array('UTF-8','SJIS','EUC-JP','ASCII','JIS') as $charcode){
            if(mb_convert_encoding($str, $charcode, $charcode) == $str){
                    return $charcode;
            }
    }
    return null;
}

/**
 * Recursively delete a directory
 *
 * @param string $dir Directory name
 * @param boolean $deleteRootToo Delete specified top-level directory as well
 *　$dirは消去したい一番上のディレクトリ
 *  $deleteRootTooは一番上のディレクトリを消去したい場合にtrueを設定
 */
function unlinkRecursive($dir, $deleteRootToo)
{
    if(!$dh = @opendir($dir))
    {
        return;
    }
    while (false != ($obj = readdir($dh)))
    {
        if($obj == '.' || $obj == '..')
        {
            continue;
         }  

        if (!@unlink($dir . '/' . $obj))
        {
           unlinkRecursive($dir.'/'.$obj, true);
       }
   }

   closedir($dh);

   if ($deleteRootToo)
   {
       @rmdir($dir);
   }
  
   return;
}
