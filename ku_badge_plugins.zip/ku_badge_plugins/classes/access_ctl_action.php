<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

//defined('MOODLE_INTERNAL') || die(); これを入れると動かない
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/badgeslib.php');

//Ajaxによるリクエストかどうかの識別を行う
//strtolower()を付けるのは、XMLHttpRequestやxmlHttpRequestで返ってくる場合があるため
if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){  
    if (isset($_POST['save_badgeid']))
    {
        $badgeid    = $_POST["save_badgeid"];
        $userid     = $_POST["save_userid"];
        $accessmode = $_POST["save_accessmode"];
        $accesspass = $_POST["save_accesspass"];
        
        save_access_mode( $badgeid, $userid, $accessmode, $accesspass );
        
        echo "\n"."DONE";
        echo "\n"."Badgeid:[$badgeid]"."\n"."Userid:[$userid]"."\n"."Mode:[$accessmode]"."\n"."PASS:[$accesspass]";
    }
    else if (isset($_POST['check_badgeid']))
    {
        $badgeid    = $_POST["check_badgeid"];
        $userid     = $_POST["check_userid"];
        $accessmode = $_POST["check_accessmode"];
        $accesspass = $_POST["check_accesspass"];

        global $DB, $USER;
        $access_table = $DB->get_record('badge_access_ctl', array('badgeid'=>$badgeid, 'userid'=>$userid));
        if(      empty( $access_table )                   ) { echo 'NG';}
        else if( $access_table->accessmode != $accessmode ) { echo 'NG['.$accessmode.']';}
        else if( $access_table->accesspass != $accesspass ) { echo 'NG['.$accesspass.']';}
        else                                                { echo 'OK';}
    }
    else { echo 'NG';}
}else{
    echo 'This access is not valid.';
    die();
}

function save_access_mode( $badgeid, $userid, $accessmode, $accesspass )
{
    global $DB, $USER;
    $access_table = $DB->get_record('badge_access_ctl', array('badgeid'=>$badgeid, 'userid'=>$userid));
    if( false == $access_table ) {
        //echo "\n"."INSERT";
        $access_table = new stdClass();
        $access_table->badgeid       = $badgeid;
        $access_table->userid        = $userid;
        $access_table->accessmode    = $accessmode;
        $access_table->accesspass    = $accesspass;
        $access_table->timecreated   = time();
        $access_table->timemodified  = time();
        $access_table->createdby     = $USER->id;
        $access_table->modifiedby    = $USER->id;
        $access_table->id = $DB->insert_record('badge_access_ctl', $access_table);
    }
    else {
        //echo "\n"."UPDATE";
        $access_table->accessmode    = $accessmode;
        $access_table->accesspass    = $accesspass;
        $access_table->timemodified  = time();
        $access_table->modifiedby    = $USER->id;
        $DB->update_record('badge_access_ctl', $access_table);
    }    
}
