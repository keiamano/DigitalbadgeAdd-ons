
M.add_detail = {};

M.add_detail.init_participation = function(Y) {
    
    Y.on('click', function(e) {
        // Presence of a show all link indicates we should redirect to
        // a page with all users listed and checked, otherwise just check
        // those already shown.
        var showallink = this.getAttribute('data-showallink');
        if (showallink) {
            window.location = showallink;
        }
        Y.all('input.usercheckbox').each(function() {
            this.set('checked', 'checked');
        });
    }, '#checkall, #checkallonpage');

    Y.on('click', function(e) {
        Y.all('input.usercheckbox').each(function() {
            this.set('checked', '');
        });
    }, '#checknone');
    
    Y.on('click', function(e) {
        var arraycheck = [];
        var saveurl;
        var i=0;
        arraycheck[i] = [];
        arraycheck[i][0] = 'badgeid';
        arraycheck[i][1] = 'courseid';
        arraycheck[i][2] = 'sectionid';
        arraycheck[i][3] = 'moduleid';
        arraycheck[i][4] = 'visible';
        arraycheck[i][5] = 'display';
        i++;
        Y.all('input.usercheckbox').each(function() {
            var j=0;
            arraycheck[i] = [];
            arraycheck[i][j++]= this.getAttribute('badgeid');
            arraycheck[i][j++]= this.getAttribute('courseid');
            arraycheck[i][j++]= this.getAttribute('sectionid');
            arraycheck[i][j++]= this.getAttribute('moduleid');
            arraycheck[i][j++]= this.getAttribute('modvisible');
            arraycheck[i][j++]= (this.get('checked') ? 1 : 0);
            saveurl = this.getAttribute('saveUrl');
            i++;
        });
        //arraycheck.forEach(function(a){ a.forEach(function(b){ console.log(b);});});
        var arraycheck_json = JSON.stringify(arraycheck);
        //$('#output').load(saveurl, {checkdata : arraycheck_json});
        $.ajax({
                type : "POST",
                url  : saveurl,
                dataType: "text",
                data: {
                    "save_detail"   : arraycheck_json
                },
                success: function(post) {
                    console.log("SAVE DETAIL SUCCESS:" + post);
                },
                error:   function(post) {
                    alert("SAVE DETAIL ERROR:" + post);
                },
                complete: function(post) {
                    //console.log("SAVE DETAIL COMPLETE:" + post);
                }
        });
    }, '#checkupdate');
};
