<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->libdir . '/badgeslib.php');
require_once($CFG->libdir . '/filelib.php');


function get_badge_browse_history(){
	global $DB, $USER;
	
	$ip = $_SERVER["REMOTE_ADDR"] ;
	
	$viewerId = $USER -> id;
	$viewerName = $USER -> username;
	$viewerFirstName = $USER -> firstname;
	$viewerLastName = $USER -> lastname;
	
	$id = required_param('hash', PARAM_ALPHANUM);
	$badge = new issued_badge($id);
	
	$badgeId = $badge->badgeid;
	$badgedata = $DB->get_record_sql("SELECT ba.id, ba.name, ba.description, ba.issuername, ba.courseid
                        FROM {badge} ba WHERE ba.id=$badgeId");
                        
    $courseId = $badgedata->courseid;
    $courseName = null;
    if(isset($courseId)){
    	$coursedata = $DB->get_record_sql("SELECT co.id, co.fullname 
                        FROM {course} co WHERE co.id=$courseId");
        $courseName = $coursedata->fullname;
    }
                       
	$ownerId  = $badge->recipient->id;
	$ownerdata = $DB->get_record_sql("SELECT us.id, us.username, us.firstname, us.lastname
                        FROM {user} us WHERE us.id=$ownerId");
                        
    $timecreated = time() ;
	
	$browse_table = new stdClass();
	$browse_table->courseid              = $courseId;
	$browse_table->coursefullname        = $courseName;
	$browse_table->badgeid               = $badgedata->id;
	$browse_table->badgename             = $badgedata->name;
	$browse_table->description           = $badgedata->description;
	$browse_table->issuername            = $badgedata->issuername;
	$browse_table->ownerid               = $ownerdata->id;
	$browse_table->ownername             = $ownerdata->username;
	$browse_table->ownerfirstname        = $ownerdata->firstname;
	$browse_table->ownerlastname         = $ownerdata->lastname;
	$browse_table->viewerid              = $viewerId;
	$browse_table->viewername            = $viewerName;
	$browse_table->viewerfirstname       = $viewerFirstName;
	$browse_table->viewerlastname        = $viewerLastName;
	$browse_table->ip                    = $ip;
	$browse_table->timecreated           = $timecreated;
	$browse_table->id = $DB->insert_record('badge_browse_history', $browse_table);
}
