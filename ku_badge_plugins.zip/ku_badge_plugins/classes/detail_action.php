<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_add_detail
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

//defined('MOODLE_INTERNAL') || die(); これを入れると動かない
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/badgeslib.php');

//Ajaxによるリクエストかどうかの識別を行う
//strtolower()を付けるのは、XMLHttpRequestやxmlHttpRequestで返ってくる場合があるため
if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){  
    if (isset($_POST['save_detail']))
    {
        $checkdata = $_POST["save_detail"];
        $arraychecks = json_decode($checkdata);
        $i=0; $j;
        $details = array();
        $labels = array();
        foreach( $arraychecks as $arraycheck){
            $j=0;
            foreach( $arraycheck as $item ){
                if($i==0){
                    $labels[$j] = $item;
                }
                else {
                    $details[$i-1][$labels[$j]] = $item;
                }
                $j++;
            }
            $i++;
        }
        save_badge_detail( $details );
        echo 'OK';
    }
    else {
        echo 'NG';
    }
}else{
    echo 'This access is not valid.';
    die();
}

function save_badge_detail( $details )
{
    global $DB, $USER;
    foreach( $details as $detail ){
        $detail_table = $DB->get_record('badge_detail',
                array(  'badgeid'  =>$detail['badgeid'],
                        'courseid' =>$detail['courseid'],
                        'sectionid'=>$detail['sectionid'],
                        'moduleid' =>$detail['moduleid'])
                );
        if( false == $detail_table ) {
            //echo "\n"."INSERT";
            $detail_table = new stdClass();
            $detail_table->badgeid       = $detail['badgeid'];
            $detail_table->courseid      = $detail['courseid'];
            $detail_table->sectionid     = $detail['sectionid'];
            $detail_table->moduleid      = $detail['moduleid'];
            $detail_table->visible       = $detail['visible'];
            $detail_table->display       = $detail['display'];
            $detail_table->timecreated   = time();
            $detail_table->timemodified  = time();
            $detail_table->createdby     = $USER->id;
            $detail_table->modifiedby    = $USER->id;
            $detail_table->id = $DB->insert_record('badge_detail', $detail_table);
        }
        else {
            //echo "\n"."UPDATE";
            $detail_table->visible       = $detail['visible'];
            $detail_table->display       = $detail['display'];
            $detail_table->timemodified  = time();
            $detail_table->modifiedby    = $USER->id;
            $DB->update_record('badge_detail', $detail_table);
        }
    }
}
