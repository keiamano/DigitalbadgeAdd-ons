<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/badgeslib.php');
require_once(__DIR__ . '/classes/detail_form.php');

$badgeid    = required_param('id', PARAM_INT);
$sortby     = optional_param('sort', 'dateissued', PARAM_ALPHA);
$sorthow    = optional_param('dir', 'DESC', PARAM_ALPHA);
$page       = optional_param('page', 0, PARAM_INT);

require_login();

if (empty($CFG->enablebadges)) {
    print_error('badgesdisabled', 'badges');
}

if (!in_array($sortby, array('firstname', 'lastname'))) {
    $sortby = 'dateissued';
}

if ($sorthow != 'ASC' and $sorthow != 'DESC') {
    $sorthow = 'DESC';
}

if ($page < 0) {
    $page = 0;
}
$jqueryFile = new moodle_url('/local/ku_badge_plugins/classes/detail_module.js');
$PAGE->requires->jquery();
$PAGE->requires->js( $jqueryFile );

$badge = new badge($badgeid);
$context = $badge->get_context();
$navurl = new moodle_url('/badges/index.php', array('type' => $badge->type));

if ($badge->type == BADGE_TYPE_COURSE) {
    if (empty($CFG->badges_allowcoursebadges)) {
        print_error('coursebadgesdisabled', 'badges');
    }
    require_login($badge->courseid);
    $navurl = new moodle_url('/badges/index.php', array('type' => $badge->type, 'id' => $badge->courseid));
    $PAGE->set_pagelayout('standard');
    navigation_node::override_active_url($navurl);
} else {
    $PAGE->set_pagelayout('admin');
    navigation_node::override_active_url($navurl, true);
}

$currenturl = new moodle_url('/local/ku_badge_plugins/detail.php', array('id' => $badge->id, 'sort' => $sortby, 'dir' => $sorthow));
$PAGE->set_context($context);
$PAGE->set_url($currenturl);
$PAGE->set_heading($badge->name);
$PAGE->set_title($badge->name);
$PAGE->navbar->add($badge->name);

$output = $PAGE->get_renderer('core', 'badges');

echo $output->header();
echo $output->heading(print_badge_image($badge, $context, 'small') . ' ' . $badge->name);
echo $output->print_badge_status_box($badge);
$output->print_badge_tabs($badgeid, $context, 'ditail');
if( badge_detail_tab_add(1) ) {
    $totalcount = $DB->count_records('badge_issued', array('badgeid' => $badge->id));
    if ($totalcount>0) {
        $action = 'setting';
        $form_class = 'detail_' . $action . '_form';
        $customdata = array('badge' => $badge, 'badgeid' => $badgeid, 'sortby' => $sortby, 'sorthow' => $sorthow, 'page' =>$page, 'action' => $action);
        $form = new $form_class($currenturl, $customdata);
        $form->display();
    } else {
        echo $output->notification(get_string('noawards', 'badges'));
    }
}

echo $OUTPUT->footer();
