<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package ku_badge_plugins
 * @copyright  Kumamoto Univ
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->libdir . '/badgeslib.php');
require_once($CFG->libdir . '/filelib.php');
require_once(__DIR__ . '/../../badges/renderer.php');

global $DB,$OUTPUT,$PAGE;

$id = required_param('hash', PARAM_ALPHANUM);
$badge = new issued_badge($id);
$userid  = $badge->recipient->id;
$badgeid = $badge->badgeid;
$accessmode = 0;
$accesspass = '';

// DB読込
$accessdata = $DB->get_record_sql("SELECT ac.id, ac.badgeid, ac.userid, ac.accessmode, ac.accesspass
                        FROM {badge_access_ctl} ac WHERE ac.badgeid=$badgeid and ac.userid=$userid");
$accessmode = "0";
if($accessdata) {
    $accessmode = $accessdata->accessmode;
    $accesspass = $accessdata->accesspass;
}

$dlgMessage = "デジタルバッジのアクセス範囲の変更";
$radiorelease = "公開";
$radioprivate = "非公開";
$radiopasswrd = "パスワード制限";
$inputpasswrd = "入力欄:";
$showDlg = "";
$showDlg .= '<div class="badge-dialog">'.$dlgMessage.'</div>';
$showDlg .= '<label class="class-access-mode">';
$showDlg .= '<input type="hidden" id=badge-access-mode value="'.$accessmode.'">';
$showDlg .= '<p></p>';
$showDlg .= '<label><input type="radio" id="id_radio-access1" name="radio-accessmode" value=1 '.($accessmode==="1" ? 'checked="checked"':'').'>'.$radiorelease.'</></label>';
$showDlg .= '</br>';
$showDlg .= '<label><input type="radio" id="id_radio-access0" name="radio-accessmode" value=0 '.($accessmode==="0" ? 'checked="checked"':'').'>'.$radioprivate.'</></label>';
$showDlg .= '</br>';
$showDlg .= '<label><input type="radio" id="id_radio-access2" name="radio-accessmode" value=2 '.($accessmode==="2" ? 'checked="checked"':'').'>'.$radiopasswrd.'</></label>';
$showDlg .= '</br>';
$showDlg .= '</label>';
$showDlg .= '<div name="input-passwd" style="margin: 0px 20px;">'.$inputpasswrd.'<input type="password" id="id_access-pass" name="badge-access-password" value="'.$accesspass.'"/></div>';
echo $showDlg;
    