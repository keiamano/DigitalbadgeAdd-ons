<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Displays different views of the logs.
 *
 * @package    report_kubadgelog
 * @copyright  1999 onwards Martin Dougiamas (http://dougiamas.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');
require_once($CFG->dirroot.'/course/lib.php');
require_once($CFG->dirroot.'/report/kubadgelog/locallib.php');
require_once($CFG->libdir.'/adminlib.php');
require_once($CFG->dirroot.'/lib/tablelib.php');
require_once(__DIR__.'/lib.php');

$id          = optional_param('id', 0, PARAM_INT);// Course ID.
$group       = optional_param('group', 0, PARAM_INT); // Group to display.
$user        = optional_param('user', 0, PARAM_INT); // User to display.
$date        = optional_param('date', 0, PARAM_INT); // Date to display.
$modid       = optional_param('modid', 0, PARAM_ALPHANUMEXT); // Module id or 'site_errors'.
$modaction   = optional_param('modaction', '', PARAM_ALPHAEXT); // An action as recorded in the logs.
$page        = optional_param('page', '0', PARAM_INT);     // Which page to show.
$perpage     = optional_param('perpage', '100', PARAM_INT); // How many per page.
$showcourses = optional_param('showcourses', false, PARAM_BOOL); // Whether to show courses if we're over our limit.
$showusers   = optional_param('showusers', false, PARAM_BOOL); // Whether to show users if we're over our limit.
$chooselog   = optional_param('chooselog', false, PARAM_BOOL);
$logformat   = optional_param('download', '', PARAM_ALPHA);
$logreader      = optional_param('logreader', '', PARAM_COMPONENT); // Reader which will be used for displaying logs.
$edulevel    = optional_param('edulevel', -1, PARAM_INT); // Educational level.
$origin      = optional_param('origin', '', PARAM_TEXT); // Event origin.

$params = array();
if (!empty($id)) {
    $params['id'] = $id;
} else {
    $site = get_site();
    $id = $site->id;
}
if ($group !== 0) {
    $params['group'] = $group;
}
if ($user !== 0) {
    $params['user'] = $user;
}
if ($date !== 0) {
    $params['date'] = $date;
}
if ($modid !== 0) {
    $params['modid'] = $modid;
}
if ($modaction !== '') {
    $params['modaction'] = $modaction;
}
if ($page !== '0') {
    $params['page'] = $page;
}
if ($perpage !== '100') {
    $params['perpage'] = $perpage;
}
if ($showcourses) {
    $params['showcourses'] = $showcourses;
}
if ($showusers) {
    $params['showusers'] = $showusers;
}
if ($chooselog) {
    $params['chooselog'] = $chooselog;
}
if ($logformat !== '') {
    $params['download'] = $logformat;
}
if ($logreader !== '') {
    $params['logreader'] = $logreader;
}
if (($edulevel != -1)) {
    $params['edulevel'] = $edulevel;
}

// Legacy store hack, as edulevel is not supported.
if ($logreader == 'logstore_legacy') {
    $params['edulevel'] = -1;
    $edulevel = -1;
}
$url = new moodle_url("/report/kubadgelog/index.php", $params);

$PAGE->set_url('/report/kubadgelog/index.php', array('id' => $id));
$PAGE->set_pagelayout('report');

// Get course details.
$course = null;
if ($id) {
    $course = $DB->get_record('course', array('id' => $id), '*', MUST_EXIST);
    require_login($course);
    $context = context_course::instance($course->id);
} else {
    require_login();
    $context = context_system::instance();
    $PAGE->set_context($context);
}

require_capability('report/kubadgelog:view', $context);


if (!empty($page)) {
    $strlogs = get_string('itemname', 'report_kubadgelog'). ": ". get_string('page', 'report_kubadgelog', $page + 1);
} else {
    $strlogs = get_string('itemname', 'report_kubadgelog');
}
$stradministration = get_string('administration');
$strreports = get_string('reports');

// Before we close session, make sure we have editing information in session.
$adminediting = optional_param('adminedit', -1, PARAM_BOOL);
if ($PAGE->user_allowed_editing() && $adminediting != -1) {
    $USER->editing = $adminediting;
}

if (empty($course) || ($course->id == $SITE->id)) {
    admin_externalpage_setup('kubadgelog', '', null, '', array('pagelayout' => 'report'));
    $PAGE->set_title($SITE->shortname .': '. $strlogs);
} else {
    $PAGE->set_title($course->shortname .': '. $strlogs);
    $PAGE->set_heading($course->fullname);
}

$reportlog = new report_kubadgelog_renderable($logreader, $course, $user, $modid, $modaction, $group, $edulevel, $showcourses, $showusers,
        $chooselog, true, $url, $date, $logformat, $page, $perpage, 'timecreated DESC', $origin);
$readers = $reportlog->get_readers();
$output = $PAGE->get_renderer('report_kubadgelog');

$heading = get_string('heading', 'report_kubadgelog');

if (empty($readers)) {
    echo $output->header();
    echo $output->heading(get_string('nologreaderenabled', 'report_kubadgelog'));
} else {
        // Delay creation of table, till called by user with filter.
        $reportlog->setup_table();

        if (empty($logformat)) {
            echo $output->header();
            echo $output->heading($heading);
            $userinfo = get_string('allparticipants');
            $dateinfo = get_string('alldays');

            if ($user) {
                $u = $DB->get_record('user', array('id' => $user, 'deleted' => 0), '*', MUST_EXIST);
                $userinfo = fullname($u, has_capability('moodle/site:viewfullnames', $context));
            }
            if ($date) {
                $dateinfo = userdate($date, get_string('strftimedaydate'));
            }
            if (!empty($course) && ($course->id != SITEID)) {
                $PAGE->navbar->add("$userinfo, $dateinfo");
            }
            
            $logs = get_kubadgelogs();
            view_browsing_history($logs);
        } else {
            $logs = get_kubadgelogs();
            csv_download($logs);
            exit();
        }
}

echo $output->footer();



function get_kubadgelogs(){
	global $DB;
	$pagesize = 100;
	
	$kubadge_logs = $DB -> get_records('badge_browse_history', null, 'timecreated DESC');
	$data = array();
	$data_list = array();
	
	foreach($kubadge_logs as $log){
		if($log->viewerid == 0){
			$viewerfullname = '-';
		}else{
			$viewerfullname = $log->viewerlastname . ' ' . $log->viewerfirstname;
		}
		
		if(empty($log->description)){
			$desc = '-';
		}else{
			$desc = $log->description;
		}
		
		$ownerfullname  = $log->ownerlastname  . ' ' . $log->ownerfirstname;
		
		array_push($data, date( "Y/m/d H:i" , $log->timecreated ));
		array_push($data, $viewerfullname);
		array_push($data, $log->ip);
		array_push($data, $log->coursefullname);
		array_push($data, $log->badgename);
		array_push($data, $ownerfullname);
		array_push($data, $desc);
		array_push($data, $log->issuername);
		
		array_push($data_list, $data);
		$data = array();
	}
	
	return $data_list;
}

function view_browsing_history($logs){
		
	$pagenation = array();
	$page_list = array();
	$count = 0;
	
	foreach($logs as $log){
		array_push($page_list, $log);
		$count++;
		
		if($count == $pagesize){
			array_push($pagenation, $page_list);
			$count = 0;
			$page_list = array();
		}
	}
	array_push($pagenation, $page_list);
	$pagenation_num = count($pagenation);
	
	//html_pagenation();
	html_form_download();
	echo html_writer::start_div('no-over-flow');
	echo html_writer::start_tag('table', array('class' => 'flexible reportlog generaltable generalbox', 'cellspacing' => '0'));
	echo html_writer::start_tag('thead'); //テーブルヘッダ
	echo html_writer::start_tag('tr');

	$table_headers = array(
		get_string('time', 'report_kubadgelog'),
		get_string('viewer', 'report_kubadgelog'),
		get_string('ip', 'report_kubadgelog'),
		get_string('course', 'report_kubadgelog'),
		get_string('badge', 'report_kubadgelog'),
		get_string('owner', 'report_kubadgelog'),
		get_string('description', 'report_kubadgelog'),
		get_string('issuer', 'report_kubadgelog')
	);
	foreach($table_headers as $header){
		echo html_writer::start_tag('th', array('class' => 'header c0', 'scope' => 'col'));
		echo $header;
		echo html_writer::end_tag('th');
	}

	echo html_writer::end_tag('tr');
	echo html_writer::end_tag('thead');
	echo html_writer::start_tag('tbody');
	
	foreach($logs as $log){
		echo html_writer::start_tag('tr', array('class' => null, 'id' => 'report_kubadgelog_r0'));
			echo html_writer::start_tag('td', array('class' => 'cell c0', 'id' => 'report_kubadgelog_r0_c0')); //アクセス日時
				echo $log[0];
			echo html_writer::end_tag('td');
			echo html_writer::start_tag('td', array('class' => 'cell c0', 'id' => 'report_kubadgelog_r0_c0')); //閲覧者
				echo $log[1];
			echo html_writer::end_tag('td');
			echo html_writer::start_tag('td', array('class' => 'cell c0', 'id' => 'report_kubadgelog_r0_c0')); //ipアドレス
				echo $log[2];
			echo html_writer::end_tag('td');
			echo html_writer::start_tag('td', array('class' => 'cell c0', 'id' => 'report_kubadgelog_r0_c0')); //コース名
				echo $log[3];
			echo html_writer::end_tag('td');
			echo html_writer::start_tag('td', array('class' => 'cell c0', 'id' => 'report_kubadgelog_r0_c0')); //バッジ名
				echo $log[4];
			echo html_writer::end_tag('td');
			echo html_writer::start_tag('td', array('class' => 'cell c0', 'id' => 'report_kubadgelog_r0_c0')); //取得者
				echo $log[5];
			echo html_writer::end_tag('td');
			echo html_writer::start_tag('td', array('class' => 'cell c0', 'id' => 'report_kubadgelog_r0_c0')); //バッジ説明
				echo $log[6];
			echo html_writer::end_tag('td');
			echo html_writer::start_tag('td', array('class' => 'cell c0', 'id' => 'report_kubadgelog_r0_c0')); //バッジ発行者
				echo $log[7];
			echo html_writer::end_tag('td');
		echo html_writer::end_tag('tr');
		
	}
	
	echo html_writer::end_tag('tbody');
	echo html_writer::end_tag('table');
	//html_pagenation();
	echo html_writer::end_div();
}


function html_pagenation(){
	echo html_writer::start_tag('nav', array('aria-label' => 'ページ'));
		echo html_writer::start_tag('ul', array('class' => 'pagination'));
			echo html_writer::start_tag('li', array('class' => 'page-item active'));
				echo html_writer::start_tag('a', array('href' => '/report/kubadgelog/index.php?id=1&modid&page=2&chooselog=1&logreader=logstore_standard', 'class' => 'page-link'));
					echo 1;
				echo html_writer::end_tag('a');
			echo html_writer::end_tag('li');
			echo html_writer::start_tag('li', array('class' => 'page-item'));
				echo html_writer::start_tag('a', array('href' => '/report/kubadgelog/index.php?id=1&modid&page=2&chooselog=1&logreader=logstore_standard', 'class' => 'page-link'));
					echo 2;
				echo html_writer::end_tag('a');
			echo html_writer::end_tag('li');
		echo html_writer::end_tag('ul');
	echo html_writer::end_tag('nav');
}


function html_form_download(){

	echo html_writer::start_tag('form', array('class' => 'dataformatselector m-a-1', 'method' => 'get', 'action' => '/moodle/report/kubadgelog/index.php'));
		echo html_writer::start_div('form-inline text_xs_right');
			echo html_writer::start_tag('label', array('class' => 'm-r-1', 'for' => 'downloadtype_download'));
				echo get_string('download-data', 'report_kubadgelog');
			echo html_writer::end_tag('label');
			echo html_writer::start_tag('select', array('class' => 'form-control', 'id' => 'downloadtype_download', 'name' => 'download'));
				echo html_writer::start_tag('option', array('value' => 'csv'));
					echo get_string('csv', 'report_kubadgelog');
				echo html_writer::end_tag('option');
			echo html_writer::end_tag('select');
			echo html_writer::start_tag('button', array('type' => 'submit', 'class' => 'btn btn-secondary'));
				echo get_string('download', 'report_kubadgelog');
			echo html_writer::end_tag('button');
		echo html_writer::end_div();
	echo html_writer::end_tag('form');

}

function csv_download($logs, $logformat){
	global $CFG;
	try{
		$file = $CFG->dataroot;
		if(!file_exists($file)){
			mkdir($file,0777,true);
		}
                
		$table_headers = array(array(
							get_string('time', 'report_kubadgelog'),
							get_string('viewer', 'report_kubadgelog'),
							get_string('ip', 'report_kubadgelog'),
							get_string('course', 'report_kubadgelog'),
							get_string('badge', 'report_kubadgelog'),
							get_string('owner', 'report_kubadgelog'),
							get_string('description', 'report_kubadgelog'),
							get_string('issuer', 'report_kubadgelog')
						));
		$csv_data = array_merge($table_headers, $logs);
		
		$csvFileName = 'kubadgelog_' . date( "Ymd_His" , time() ) . '.csv';
		$filePath = $file . "/" . $csvFileName;
		
		$fp = fopen($filePath, 'w');
		if ($fp === FALSE) {
			throw new Exception('ファイルの書き込みに失敗しました。');
		}
		
		foreach ($csv_data as $log) {
			mb_convert_variables('SJIS', 'UTF-8', $log);
			fputcsv($fp, $log);
		}
		
		fclose($fp);
		
		header('Content-Type: application/octet-stream');
		
		header('Content-Disposition: attachment; filename="'.$csvFileName.'"'); 
		header('Content-Transfer-Encoding: binary');
		header('Content-Length: ' . filesize($filePath));
		readfile($filePath);

		unlink($filePath);
		
	} catch(Exception $e){
		
	} 
}
